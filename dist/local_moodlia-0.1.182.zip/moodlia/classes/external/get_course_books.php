<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Get course books external function.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_moodlia\operation\get_course_books as get_course_books_operation;

/**
 * External API adapter for get_course_books.
 */
class get_course_books extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'course_id' => new external_value(PARAM_INT, 'Moodle course id'),
        ]);
    }

    public static function execute(int $course_id): array {
        ['course_id' => $courseid] = self::validate_parameters(self::execute_parameters(), [
            'course_id' => $course_id,
        ]);

        $systemcontext = \context_system::instance();
        self::validate_context($systemcontext);
        require_capability('local/moodlia:useapi', $systemcontext);

        $coursecontext = \context_course::instance($courseid);
        self::validate_context($coursecontext);
        require_capability('moodle/course:view', $coursecontext);

        return get_course_books_operation::execute((int) $courseid);
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'course_id' => new external_value(PARAM_INT, 'Moodle course id'),
            'count' => new external_value(PARAM_INT, 'Returned Book count'),
            'books' => new external_multiple_structure(self::book_summary_structure()),
            'warnings' => self::warnings_structure(),
        ]);
    }

    public static function book_summary_structure(): external_single_structure {
        return new external_single_structure([
            'book_id' => new external_value(PARAM_INT, 'Book instance id'),
            'module_id' => new external_value(PARAM_INT, 'Book course module id'),
            'course_id' => new external_value(PARAM_INT, 'Moodle course id'),
            'name' => new external_value(PARAM_TEXT, 'Book activity name'),
            'numbering' => new external_value(PARAM_INT, 'Book numbering mode'),
            'custom_titles' => new external_value(PARAM_BOOL, 'Whether custom chapter titles are enabled'),
            'revision' => new external_value(PARAM_INT, 'Book revision number'),
            'time_modified' => new external_value(PARAM_INT, 'Last modification timestamp'),
            'url' => new external_value(PARAM_URL, 'Book URL'),
        ]);
    }

    public static function warnings_structure(): external_multiple_structure {
        return new external_multiple_structure(new external_single_structure([
            'item' => new external_value(PARAM_TEXT, 'Warning item'),
            'item_id' => new external_value(PARAM_INT, 'Warning item id'),
            'warning_code' => new external_value(PARAM_TEXT, 'Warning code'),
            'message' => new external_value(PARAM_TEXT, 'Warning message'),
        ]));
    }
}
