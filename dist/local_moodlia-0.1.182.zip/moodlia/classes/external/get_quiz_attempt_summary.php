<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Get quiz attempt summary external function.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_moodlia\operation\get_quiz_attempt_summary as get_quiz_attempt_summary_operation;
use local_moodlia\operation\question_tools;

/**
 * External API adapter for get_quiz_attempt_summary.
 */
class get_quiz_attempt_summary extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'quiz_module_id' => new external_value(PARAM_INT, 'Quiz course module id'),
            'attempt_id' => new external_value(PARAM_INT, 'Quiz attempt id'),
            'preflight_data' => new external_value(PARAM_RAW, 'JSON array of preflight name/value pairs', VALUE_DEFAULT, '[]'),
        ]);
    }

    public static function execute(int $quiz_module_id, int $attempt_id, string $preflight_data = '[]'): array {
        [
            'quiz_module_id' => $quizmoduleid,
            'attempt_id' => $attemptid,
            'preflight_data' => $preflightdata,
        ] = self::validate_parameters(self::execute_parameters(), [
            'quiz_module_id' => $quiz_module_id,
            'attempt_id' => $attempt_id,
            'preflight_data' => $preflight_data,
        ]);

        get_quiz_attempt_data::validate_quiz_attempt_context((int) $quizmoduleid);

        return get_quiz_attempt_summary_operation::execute(
            (int) $quizmoduleid,
            (int) $attemptid,
            question_tools::decode_preflight_data((string) $preflightdata)
        );
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'quiz_id' => new external_value(PARAM_INT, 'Quiz instance id'),
            'quiz_module_id' => new external_value(PARAM_INT, 'Quiz course module id'),
            'attempt_id' => new external_value(PARAM_INT, 'Quiz attempt id'),
            'total_unanswered' => new external_value(PARAM_INT, 'Total unanswered questions'),
            'questions' => new external_multiple_structure(get_quiz_attempt_data::question_structure()),
            'warnings' => get_quiz_attempt_data::warnings_structure(),
        ]);
    }
}
