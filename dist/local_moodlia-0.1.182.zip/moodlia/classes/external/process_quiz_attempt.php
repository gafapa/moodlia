<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Process quiz attempt external function.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use local_moodlia\operation\process_quiz_attempt as process_quiz_attempt_operation;
use local_moodlia\operation\question_tools;

/**
 * External API adapter for process_quiz_attempt.
 */
class process_quiz_attempt extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'quiz_module_id' => new external_value(PARAM_INT, 'Quiz course module id'),
            'attempt_id' => new external_value(PARAM_INT, 'Quiz attempt id'),
            'data' => new external_value(PARAM_RAW, 'JSON array of attempt response name/value pairs', VALUE_DEFAULT, '[]'),
            'finish_attempt' => new external_value(PARAM_BOOL, 'Whether to finish the attempt', VALUE_DEFAULT, false),
            'time_up' => new external_value(PARAM_BOOL, 'Whether processing is due to timer expiry', VALUE_DEFAULT, false),
            'preflight_data' => new external_value(PARAM_RAW, 'JSON array of preflight name/value pairs', VALUE_DEFAULT, '[]'),
        ]);
    }

    public static function execute(
        int $quiz_module_id,
        int $attempt_id,
        string $data = '[]',
        bool $finish_attempt = false,
        bool $time_up = false,
        string $preflight_data = '[]'
    ): array {
        [
            'quiz_module_id' => $quizmoduleid,
            'attempt_id' => $attemptid,
            'data' => $attemptdata,
            'finish_attempt' => $finishattempt,
            'time_up' => $timeup,
            'preflight_data' => $preflightdata,
        ] = self::validate_parameters(self::execute_parameters(), [
            'quiz_module_id' => $quiz_module_id,
            'attempt_id' => $attempt_id,
            'data' => $data,
            'finish_attempt' => $finish_attempt,
            'time_up' => $time_up,
            'preflight_data' => $preflight_data,
        ]);

        get_quiz_attempt_data::validate_quiz_attempt_context((int) $quizmoduleid);

        return process_quiz_attempt_operation::execute(
            (int) $quizmoduleid,
            (int) $attemptid,
            question_tools::decode_quiz_attempt_data((string) $attemptdata),
            (bool) $finishattempt,
            (bool) $timeup,
            question_tools::decode_preflight_data((string) $preflightdata)
        );
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'quiz_id' => new external_value(PARAM_INT, 'Quiz instance id'),
            'quiz_module_id' => new external_value(PARAM_INT, 'Quiz course module id'),
            'attempt_id' => new external_value(PARAM_INT, 'Quiz attempt id'),
            'state' => new external_value(PARAM_ALPHANUMEXT, 'Attempt state after processing'),
            'finished' => new external_value(PARAM_BOOL, 'Whether the attempt is finished'),
            'warnings' => get_quiz_attempt_data::warnings_structure(),
        ]);
    }
}
