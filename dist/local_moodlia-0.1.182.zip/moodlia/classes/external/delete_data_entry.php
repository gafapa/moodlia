<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Delete database entry external function.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use local_moodlia\operation\data_tools;
use local_moodlia\operation\delete_data_entry as delete_data_entry_operation;

/**
 * External API adapter for delete_data_entry.
 */
class delete_data_entry extends external_api {
    /**
     * Define input parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'course_id' => new external_value(PARAM_INT, 'Moodle course id'),
            'module_id' => new external_value(PARAM_INT, 'Database course module id'),
            'entry_id' => new external_value(PARAM_INT, 'Database entry id'),
        ]);
    }

    /**
     * Execute the external function.
     *
     * @param int $course_id Moodle course id.
     * @param int $module_id Database course module id.
     * @param int $entry_id Database entry id.
     * @return array
     */
    public static function execute(int $course_id, int $module_id, int $entry_id): array {
        [
            'course_id' => $courseid,
            'module_id' => $moduleid,
            'entry_id' => $entryid,
        ] = self::validate_parameters(self::execute_parameters(), [
            'course_id' => $course_id,
            'module_id' => $module_id,
            'entry_id' => $entry_id,
        ]);

        $systemcontext = \context_system::instance();
        self::validate_context($systemcontext);
        require_capability('local/moodlia:useapi', $systemcontext);

        $course = get_course($courseid);
        $cm = data_tools::get_data_module($course, (int) $moduleid);
        $modulecontext = \context_module::instance($cm->id);
        self::validate_context($modulecontext);
        if (!has_any_capability(['mod/data:manageentries', 'mod/data:writeentry'], $modulecontext)) {
            throw new \required_capability_exception($modulecontext, 'mod/data:manageentries', 'nopermissions', '');
        }

        return delete_data_entry_operation::execute((int) $courseid, (int) $moduleid, (int) $entryid);
    }

    /**
     * Define output structure.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'deleted' => new external_value(PARAM_BOOL, 'Whether the entry was deleted'),
            'id' => new external_value(PARAM_INT, 'Deleted entry id'),
        ]);
    }
}
