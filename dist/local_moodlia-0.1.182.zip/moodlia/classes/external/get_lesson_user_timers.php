<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Get Lesson user timers external function.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_moodlia\operation\get_lesson_user_timers as get_lesson_user_timers_operation;
use local_moodlia\operation\lesson_tools;

/**
 * External API adapter for get_lesson_user_timers.
 */
class get_lesson_user_timers extends external_api {
    /**
     * Define input parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'course_id' => new external_value(PARAM_INT, 'Moodle course id'),
            'module_id' => new external_value(PARAM_INT, 'Lesson course module id'),
            'user_id' => new external_value(PARAM_INT, 'Moodle user id. Zero means current user.', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * Execute the external function.
     *
     * @param int $course_id Moodle course id.
     * @param int $module_id Lesson course module id.
     * @param int $user_id Moodle user id.
     * @return array
     */
    public static function execute(int $course_id, int $module_id, int $user_id = 0): array {
        [
            'course_id' => $courseid,
            'module_id' => $moduleid,
            'user_id' => $userid,
        ] = self::validate_parameters(self::execute_parameters(), [
            'course_id' => $course_id,
            'module_id' => $module_id,
            'user_id' => $user_id,
        ]);

        $systemcontext = \context_system::instance();
        self::validate_context($systemcontext);
        require_capability('local/moodlia:useapi', $systemcontext);

        $course = get_course($courseid);
        $cm = lesson_tools::get_lesson_module($course, (int) $moduleid);
        $modulecontext = \context_module::instance($cm->id);
        self::validate_context($modulecontext);
        require_capability('mod/lesson:view', $modulecontext);

        return get_lesson_user_timers_operation::execute((int) $courseid, (int) $moduleid, (int) $userid);
    }

    /**
     * Define output structure.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'module_id' => new external_value(PARAM_INT, 'Lesson course module id'),
            'lesson_id' => new external_value(PARAM_INT, 'Lesson instance id'),
            'user_id' => new external_value(PARAM_INT, 'Moodle user id, or 0 when current user was used'),
            'count' => new external_value(PARAM_INT, 'Returned timer count'),
            'timers' => new external_multiple_structure(new external_single_structure([
                'timer_id' => new external_value(PARAM_INT, 'Timer id'),
                'lesson_id' => new external_value(PARAM_INT, 'Lesson instance id'),
                'module_id' => new external_value(PARAM_INT, 'Lesson course module id'),
                'user_id' => new external_value(PARAM_INT, 'Moodle user id'),
                'start_time' => new external_value(PARAM_INT, 'Timer start timestamp'),
                'lesson_time' => new external_value(PARAM_INT, 'Last lesson access timestamp during the timer'),
                'completed' => new external_value(PARAM_BOOL, 'Whether the timer session completed the lesson'),
                'time_modified_offline' => new external_value(PARAM_INT, 'Offline modification timestamp'),
            ])),
            'warnings' => get_lesson_access_information::warnings_structure(),
        ]);
    }
}
