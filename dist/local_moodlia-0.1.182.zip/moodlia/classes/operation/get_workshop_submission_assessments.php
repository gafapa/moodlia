<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Get workshop submission assessments operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Lists Moodle Workshop assessments for a submission through Moodle external APIs.
 */
class get_workshop_submission_assessments {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $moduleid Workshop course module id.
     * @param int $submissionid Workshop submission id.
     * @return array
     */
    public static function execute(int $courseid, int $moduleid, int $submissionid): array {
        workshop_tools::require_workshop_api();

        $course = course_tools::get_course($courseid);
        $cm = workshop_tools::get_workshop_module($course, $moduleid);
        $submission = workshop_tools::get_submission($cm, $submissionid);
        $result = \mod_workshop_external::get_submission_assessments((int) $submission['submission_id']);
        $assessments = workshop_tools::assessments_to_response($cm, $result['assessments'] ?? []);

        return [
            'course_id' => (int) $course->id,
            'module_id' => (int) $cm->id,
            'workshop_id' => (int) $cm->instance,
            'submission_id' => (int) $submission['submission_id'],
            'count' => count($assessments),
            'assessments' => $assessments,
        ];
    }
}
