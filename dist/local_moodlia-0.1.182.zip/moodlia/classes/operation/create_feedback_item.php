<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Create feedback item operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Creates an item in a Moodle Feedback activity through Moodle item APIs.
 */
class create_feedback_item {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $moduleid Feedback course module id.
     * @param string $type Feedback item type.
     * @param string|null $name Feedback item name.
     * @param string $definitionjson JSON item definition.
     * @param int|null $position Optional one-based position.
     * @param string|null $label Optional item label.
     * @param bool|null $required Optional required flag.
     * @param int|null $dependitemid Optional dependency item id.
     * @param string|null $dependvalue Optional dependency value.
     * @return array
     */
    public static function execute(
        int $courseid,
        int $moduleid,
        string $type,
        ?string $name,
        string $definitionjson,
        ?int $position = null,
        ?string $label = null,
        ?bool $required = null,
        ?int $dependitemid = null,
        ?string $dependvalue = null
    ): array {
        $course = course_tools::get_course($courseid);
        $cm = feedback_tools::get_feedback_module($course, $moduleid);
        $definition = feedback_tools::decode_item_definition($definitionjson);

        return feedback_tools::save_item(
            $course,
            $cm,
            $type,
            $name,
            $definition,
            $position,
            $label,
            $required,
            $dependitemid,
            $dependvalue
        );
    }
}
