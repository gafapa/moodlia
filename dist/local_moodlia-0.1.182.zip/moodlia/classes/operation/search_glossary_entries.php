<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Search glossary entries operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Searches Moodle glossary entries through Moodle external APIs.
 */
class search_glossary_entries {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $moduleid Glossary course module id.
     * @param string $query Search query.
     * @param bool $fullsearch Search definitions too.
     * @param string $order Sort field.
     * @param string $sort Sort direction.
     * @param int $from Offset.
     * @param int $limit Limit.
     * @param bool $includenotapproved Include non-approved entries where allowed.
     * @return array
     */
    public static function execute(
        int $courseid,
        int $moduleid,
        string $query,
        bool $fullsearch = true,
        string $order = 'CONCEPT',
        string $sort = 'ASC',
        int $from = 0,
        int $limit = 20,
        bool $includenotapproved = false
    ): array {
        glossary_tools::require_glossary_api();

        $course = course_tools::get_course($courseid);
        $cm = glossary_tools::get_glossary_module($course, $moduleid);
        $order = strtoupper(clean_param($order, PARAM_ALPHA));
        $sort = strtoupper(clean_param($sort, PARAM_ALPHA));

        $result = glossary_tools::search_entries($cm, $query, $fullsearch, $order, $sort, $from, $limit, $includenotapproved);

        return [
            'course_id' => (int) $course->id,
            'module_id' => (int) $cm->id,
            'glossary_id' => (int) $cm->instance,
            'count' => $result['count'],
            'entries' => $result['entries'],
        ];
    }
}
