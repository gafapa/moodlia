<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Upload folder file operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Uploads a file into a Moodle folder activity through Moodle File API.
 */
class upload_folder_file {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $moduleid Folder course module id.
     * @param string $filename Target filename.
     * @param string $uploadreference Base64-encoded file content.
     * @return array
     */
    public static function execute(int $courseid, int $moduleid, string $filename, string $uploadreference): array {
        module_tools::require_module_api();

        $course = course_tools::get_course($courseid);
        $cm = module_file_tools::get_folder_module($course, $moduleid);
        $context = \context_module::instance($cm->id);

        $filename = clean_param(trim($filename), PARAM_FILE);
        if ($filename === '') {
            throw new \invalid_parameter_exception('filename is required.');
        }

        $content = base64_decode($uploadreference, true);
        if ($content === false) {
            throw new \invalid_parameter_exception('upload_reference must be base64-encoded file content.');
        }

        $maxbytes = 2 * 1024 * 1024;
        if (strlen($content) > $maxbytes) {
            throw new \invalid_parameter_exception('File content exceeds the 2 MB API limit.');
        }

        $fs = get_file_storage();
        $existing = $fs->get_file($context->id, 'mod_folder', 'content', 0, '/', $filename);
        if ($existing && !$existing->is_directory()) {
            $existing->delete();
        }

        $file = $fs->create_file_from_string([
            'contextid' => $context->id,
            'component' => 'mod_folder',
            'filearea' => 'content',
            'itemid' => 0,
            'filepath' => '/',
            'filename' => $filename,
        ], $content);

        rebuild_course_cache($course->id, true);

        return module_file_tools::folder_file_download_to_response($cm, $file);
    }
}
