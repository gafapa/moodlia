<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Delete feedback item operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Deletes an item from a Moodle Feedback activity through Moodle APIs.
 */
class delete_feedback_item {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $moduleid Feedback course module id.
     * @param int $itemid Feedback item id.
     * @return array
     */
    public static function execute(int $courseid, int $moduleid, int $itemid): array {
        feedback_tools::require_feedback_api();

        $course = course_tools::get_course($courseid);
        $cm = feedback_tools::get_feedback_module($course, $moduleid);
        feedback_tools::get_item($cm, $itemid);

        feedback_delete_item($itemid, true, false);
        rebuild_course_cache($course->id, true);

        return [
            'deleted' => true,
            'id' => $itemid,
        ];
    }
}
