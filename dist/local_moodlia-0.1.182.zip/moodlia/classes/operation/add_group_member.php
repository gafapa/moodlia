<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Add group member operation.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodlia\operation;

defined('MOODLE_INTERNAL') || die();

/**
 * Adds a user to a Moodle course group.
 */
class add_group_member {
    /**
     * Execute the operation.
     *
     * @param int $courseid Moodle course id.
     * @param int $groupid Moodle group id.
     * @param int $userid Moodle user id.
     * @return array
     */
    public static function execute(int $courseid, int $groupid, int $userid): array {
        $course = course_tools::get_course($courseid);
        $group = group_tools::get_group((int) $course->id, $groupid);
        $user = enrolment_tools::get_user($userid);

        groups_add_member((int) $group->id, (int) $user->id);

        return [
            'course_id' => (int) $course->id,
            'group_id' => (int) $group->id,
            'user_id' => (int) $user->id,
            'added' => true,
        ];
    }
}
