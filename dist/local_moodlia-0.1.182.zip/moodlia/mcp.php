<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Minimal JSON-RPC MCP endpoint for MoodlIA.
 *
 * @package    local_moodlia
 * @copyright  2026
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('NO_MOODLE_COOKIES', true);
define('AJAX_SCRIPT', true);
define('NO_DEBUG_DISPLAY', true);

require_once(__DIR__ . '/../../config.php');

/**
 * Send a JSON-RPC response.
 *
 * @param mixed $id Request id.
 * @param mixed $result Result payload.
 * @return never
 */
function local_moodlia_mcp_result($id, $result): never {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'jsonrpc' => '2.0',
        'id' => $id,
        'result' => $result,
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Send a JSON-RPC error.
 *
 * @param mixed $id Request id.
 * @param int $code JSON-RPC error code.
 * @param string $message Error message.
 * @param int $httpstatus HTTP status code.
 * @param string $canonicalcode Canonical transport-independent error code.
 * @param array $details Additional safe error metadata.
 * @return never
 */
function local_moodlia_mcp_error(
    $id,
    int $code,
    string $message,
    int $httpstatus = 200,
    string $canonicalcode = 'moodle_error',
    array $details = []
): never {
    http_response_code($httpstatus);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'jsonrpc' => '2.0',
        'id' => $id,
        'error' => [
            'code' => $code,
            'message' => $message,
            'data' => [
                'code' => $canonicalcode,
                'details' => $details,
            ],
        ],
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Map Moodle REST error payloads to canonical error codes.
 *
 * @param array $payload Moodle REST error payload.
 * @return string
 */
function local_moodlia_mcp_moodle_error_code(array $payload): string {
    $combined = strtolower(($payload['errorcode'] ?? '') . ' ' . ($payload['exception'] ?? ''));
    if (str_contains($combined, 'invalid') || str_contains($combined, 'parameter')) {
        return 'invalid_parameters';
    }
    if (str_contains($combined, 'capability') || str_contains($combined, 'permission') || str_contains($combined, 'access')) {
        return 'missing_capability';
    }
    if (str_contains($combined, 'notfound') || str_contains($combined, 'not_found')) {
        return 'not_found';
    }
    if (str_contains($combined, 'coding_exception')) {
        return 'internal_error';
    }

    return 'moodle_error';
}

/**
 * Read the bearer token from the Authorization header.
 *
 * @return string
 */
function local_moodlia_mcp_bearer_token(): string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }

    if (!preg_match('/^Bearer\s+(.+)$/', trim($header), $matches)) {
        local_moodlia_mcp_error(null, -32001, 'Missing bearer token.', 401, 'missing_capability');
    }

    return trim($matches[1]);
}

/**
 * Normalize MCP tool arguments for Moodle REST form encoding.
 *
 * @param mixed $id Request id.
 * @param mixed $arguments Tool arguments.
 * @return array
 */
function local_moodlia_mcp_normalize_arguments($id, $arguments): array {
    if ($arguments === null) {
        return [];
    }

    if (!is_array($arguments)) {
        local_moodlia_mcp_error($id, -32602, 'Tool arguments must be an object.', 200, 'invalid_parameters');
    }

    $normalized = [];
    foreach ($arguments as $key => $value) {
        if (is_bool($value)) {
            $normalized[$key] = $value ? '1' : '0';
            continue;
        }

        if (is_array($value) || is_object($value)) {
            $normalized[$key] = json_encode($value, JSON_UNESCAPED_SLASHES);
            continue;
        }

        if ($value !== null) {
            $normalized[$key] = (string) $value;
        }
    }

    return $normalized;
}

/**
 * Call the matching Moodle REST web service function.
 *
 * @param string $token Moodle REST token.
 * @param string $toolname Canonical operation name.
 * @param array $arguments Tool arguments.
 * @param mixed $id Request id.
 * @return mixed
 */
function local_moodlia_mcp_call_rest(string $token, string $toolname, array $arguments, $id = null) {
    global $CFG;

    $body = array_merge([
        'wstoken' => $token,
        'wsfunction' => 'local_moodlia_' . $toolname,
        'moodlewsrestformat' => 'json',
    ], $arguments);

    $curl = curl_init($CFG->wwwroot . '/webservice/rest/server.php');
    if ($curl === false) {
        local_moodlia_mcp_error($id, -32603, 'Unable to initialize REST transport.', 200, 'transport_error');
    }

    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($body, '', '&'),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);

    $raw = curl_exec($curl);
    $error = curl_error($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    curl_close($curl);

    if ($raw === false) {
        local_moodlia_mcp_error($id, -32002, 'REST transport failed: ' . $error, 200, 'transport_error');
    }

    $payload = json_decode($raw, true);
    if ($payload === null && json_last_error() !== JSON_ERROR_NONE) {
        local_moodlia_mcp_error($id, -32003, 'REST transport returned invalid JSON.', 200, 'transport_error');
    }

    if ($status < 200 || $status >= 300) {
        local_moodlia_mcp_error($id, -32004, 'REST transport returned HTTP ' . $status . '.', 200, 'transport_error', [
            'http_status' => $status,
        ]);
    }

    if (is_array($payload) && (isset($payload['exception']) || isset($payload['errorcode']))) {
        $message = $payload['message'] ?? $payload['errorcode'] ?? 'Moodle REST error.';
        local_moodlia_mcp_error($id, -32005, $message, 200, local_moodlia_mcp_moodle_error_code($payload), [
            'moodle_errorcode' => $payload['errorcode'] ?? null,
            'moodle_exception' => $payload['exception'] ?? null,
        ]);
    }

    return $payload;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    local_moodlia_mcp_error(null, -32600, 'Only POST requests are supported.', 405, 'invalid_parameters');
}

$token = local_moodlia_mcp_bearer_token();
$rawrequest = file_get_contents('php://input');
$request = json_decode($rawrequest ?: '', true);

if (!is_array($request)) {
    local_moodlia_mcp_error(null, -32700, 'Invalid JSON request.', 200, 'invalid_parameters');
}

$id = $request['id'] ?? null;
$method = $request['method'] ?? null;
$params = $request['params'] ?? [];

if (($request['jsonrpc'] ?? null) !== '2.0' || !is_string($method)) {
    local_moodlia_mcp_error($id, -32600, 'Invalid JSON-RPC request.', 200, 'invalid_parameters');
}

if ($method === 'tools/list') {
    local_moodlia_mcp_call_rest($token, 'get_current_user', [], $id);
    local_moodlia_mcp_result($id, [
        'tools' => \local_moodlia\mcp\manifest::tools(),
    ]);
}

if ($method === 'tools/call') {
    if (!is_array($params) || !isset($params['name']) || !is_string($params['name'])) {
        local_moodlia_mcp_error($id, -32602, 'tools/call requires a tool name.', 200, 'invalid_parameters');
    }

    $toolname = $params['name'];
    if (!in_array($toolname, \local_moodlia\mcp\manifest::tool_names(), true)) {
        local_moodlia_mcp_error($id, -32601, 'Unknown tool: ' . $toolname, 200, 'invalid_parameters', [
            'tool' => $toolname,
        ]);
    }

    $arguments = local_moodlia_mcp_normalize_arguments($id, $params['arguments'] ?? []);
    local_moodlia_mcp_result($id, local_moodlia_mcp_call_rest($token, $toolname, $arguments, $id));
}

local_moodlia_mcp_error($id, -32601, 'Unknown method: ' . $method, 200, 'invalid_parameters', [
    'method' => $method,
]);
